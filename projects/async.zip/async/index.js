import './index.html';
import './main.css';

const apiUrl = 'https://jsonplaceholder.typicode.com/posts';
let posts = [];

async function getPosts() {
  return await fetch(apiUrl).then((res) => res.json());
}

function render(dataContent) {
  const postBlock = document.querySelector('.posts');
  postBlock.innerHTML = '';
  dataContent.map((post) => {
    postBlock.innerHTML += `
      <div class="post-item">
        <h3>${post.title}</h3>
        <span>${post.body}</span>
        <button id="${post.id}" class="btn-remove">Удалить</button>
      </div>
`;
  });
}

document.addEventListener('DOMContentLoaded', async () => {
  posts = await getPosts();
  render(posts);
});

document.querySelector('.search-input').addEventListener('input', (event) => {
  filterPosts(event.target.value);
});

document.querySelector('.posts').addEventListener('click', (event) => {
  if (event.target.id) {
    deletePost(+event.target.id);
  }
});

function filterPosts(value) {
  posts = posts.filter((post) => post.title.includes(value));
  render(posts);
}

function deletePost(id) {
  posts = posts.filter((post) => post.id !== id);
  render(posts);
}

// Frontend --> BackEnd ---> Db query ---> FrontEnd

// console.log('FrontEnd: Делаю запрос на сервер');
// console.log('....');

// setTimeout(() => {
//   console.log('BackEnd: Запрашиваю базу данных');
//   console.log('....');
//
//   setTimeout(() => {
//     console.log('Db: Делаю выборку и отдаю данные');
//     console.log('....');
//     setTimeout(() => {
//       console.log('BackEnd: Модифициирую данные и отдаю обратно');
//       console.log('....');
//       setTimeout(() => {
//         console.log('FrontEnd: получил данные от сервера');
//         console.log('....');
//         setTimeout(() => {
//           console.log('FrontEnd: получил данные от сервера');
//           console.log('....');
//         });
//         setTimeout(() => {
//           console.log('FrontEnd: получил данные от сервера');
//           console.log('....');
//         });
//           setTimeout(() => {
//             console.log('FrontEnd: получил данные от сервера');
//             console.log('....');
//           });
//       });
//     });
//   });
// }, 2000);

// new Promise((resolve, reject) => {
//   setTimeout(() => {
//     console.log('BackEnd: Запрашиваю базу данных');
//     console.log('....');
//     resolve();
//   });
// })
//   .then(() => {
//     return new Promise((resolve, reject) => {
//       setTimeout(() => {
//         console.log('BackEnd: Запрашиваю базу данных');
//         console.log('....');
//         resolve({ userName: 'Boris', userId: 89 });
//         // reject('Some Error');
//       });
//     });
//   })
//   .then((data) => {
//     return new Promise((resolve, reject) => {
//       setTimeout(() => {
//         console.log('Db: Делаю выборку и отдаю данные');
//         console.log('....');
//         data.isModified = true;
//         console.log(data);
//         resolve();
//       });
//     });
//   })
//   .catch((error) => console.log(error))
//   .finally(() => console.log('In Finally method'));
